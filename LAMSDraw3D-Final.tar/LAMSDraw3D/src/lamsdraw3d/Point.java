/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lamsdraw3d;

import java.awt.Color;

/**
 *
 * @author tyjen
 */
public class Point {
    public int cc;
    public Color c;
    public int size;
    
    public Point(int cc, Color c, int size){
        this.cc = cc;
        this.c = c;
        this.size = size;
    }
}
