/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lamsdraw3d;

import java.awt.Color;

/**
 *
 * @author tyjen
 */
public class Line {
    public Integer a;
    public Integer b;
    public Color c;
    
    public Line(Integer a, Integer b, Color c){
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
